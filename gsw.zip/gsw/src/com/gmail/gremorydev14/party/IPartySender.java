package com.gmail.gremorydev14.party;

import org.bukkit.entity.Player;

public interface IPartySender {
	
	public void checkPartySend(Player p, String server);
}
