package com.gmail.gremorydev14.party.bukkit;

public class PartySender {
	
	
}
